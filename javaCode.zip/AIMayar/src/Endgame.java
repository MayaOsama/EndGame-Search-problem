import java.util.HashSet;
import java.util.Iterator;

public class Endgame extends GenericSearch{
	String ironManPosition;
	String thanosPostion;
	HashSet<String> stones;
	HashSet<String> warriors;
	int height;
	int width;

	/*
	 * To start searching for an EndGame problem we need to initialise it with:
	 * 	 the initial state which is specific to Endgame containing the initial position of IronMan 
	 *  and every thing in the grid/world : Position of Thanos, each stone and each warrior
	 */
	public Endgame(StateEndgame initialState, ActionEndgame actions,
			String thanosPostion,String height,String width) {
		super(initialState, actions);
		this.height = Integer.parseInt(height);
		this.width = Integer.parseInt(width);
		ironManPosition= initialState.getPosition();
		stones = initialState.getStonesLeft();
		warriors = initialState.getWarriorsLeft();
		this.thanosPostion= thanosPostion;

	}

	/*
	 *  A helper method used to check if there is a warrior around a given position
	 *   takes as input a String of the position and a HashSet containing the warriors positions
	 *   returns an array of boolean consists of 4 cells each cell represents whether there exits a warrior to that position or not
	 *   position [0] of the array is true if there is a warrior in the cell above the given position otherwise its false
	 *   position [1] is true if there is a warrior in the cell below the given position otherwise its false
	 *   position [2] is true if there is a warrior in the cell on the right of the given position otherwise its false
	 *   position [3] is true if there is a warrior in the cell on the left of the given position otherwise its false
	 */

	public boolean[] warriorsAround(String position, HashSet<String> warriors){
		// UP DOWN RIGHT LEFT
		boolean[] around= new boolean[4];
		String[] pos = position.split(",");
		int postionX= Integer.parseInt(pos[0]+"");
		int postionY= Integer.parseInt(pos[1]+"");
		if(warriors.contains((postionX-1)+","+(postionY)))
			around[0]=true;

		if(warriors.contains((postionX+1)+","+(postionY)))
			around[1]=true;

		if(warriors.contains((postionX)+","+(postionY+1)))
			around[2]=true;

		if(warriors.contains((postionX)+","+(postionY-1)))
			around[3]=true;
		return around;
	}


	/* A helper method used to check if Thanos is around a given state( and we get the current position from the state) 
	 * 	  since Thanos's position is fixed
	 * 	returns an array of boolean consists of 4 cells each cell represents whether Thanos is any cell around Iron man's position or in the same cell
	 * 	position [0] of the array is true if Thanos in the cell above the given position otherwise its false
	 * 	position [1] is true if Thanos is in the cell below the given position otherwise its false
	 * position [2] is true if Thanos is in the cell on the right of the given position otherwise its false
	 * 	position [3] is true if Thanos is in the cell on the left of the given position otherwise its false
	 * position [4] is true if Thanos is in the same cell of the given position otherwise its false
	 * 
	 */
	public boolean[] thanosAround(StateEndgame state){
		// UP DOWN RIGHT LEFT SAMECELL
		boolean[] around= new boolean[5];
		String[] pos= state.getPosition().split(",");
		int postionX= Integer.parseInt(pos[0]+"");
		int postionY= Integer.parseInt(pos[1]+"");
		if(Integer.parseInt(thanosPostion.split(",")[0])== postionX-1 &&
				Integer.parseInt(thanosPostion.split(",")[1])== postionY)
			around[0]=true;

		if(Integer.parseInt(thanosPostion.split(",")[0])== postionX+1 &&
				Integer.parseInt(thanosPostion.split(",")[1])== postionY)
			around[1]=true;

		if(Integer.parseInt(thanosPostion.split(",")[0])== postionX &&
				Integer.parseInt(thanosPostion.split(",")[1])== postionY+1)
			around[2]=true;

		if(Integer.parseInt(thanosPostion.split(",")[0])== postionX &&
				Integer.parseInt(thanosPostion.split(",")[1])== postionY-1)
			around[3]=true;

		if(Integer.parseInt(thanosPostion.split(",")[0])== postionX &&
				Integer.parseInt(thanosPostion.split(",")[1])== postionY)
			around[4]=true;

		return around;
	}

	//a helper method to calculate the damage if IronMan is standing next to a warrior(s) or Thanos
	public int[] calculateDamage(StateEndgame state, boolean[] warriorsAround, boolean[] thanosAround) {
		int countWarriors = 0;
		for(int i = 0; i < warriorsAround.length; i++) {
			if(warriorsAround[i]) {
				countWarriors++;
			}
		}
		int thanos = 0;
		for(int i = 0; i < thanosAround.length; i++) {
			if(thanosAround[i]) {
				thanos++;
			}
		}
		return new int[] {(thanos*5) , countWarriors};
	}

	/*
	 *goalTest checks if a given node is a goal node and passes the goal test
	 *returns true if IronMan can collect all 6 stones, be in the same cell as Thanos and still have damage less than 100
	 */
	@Override
	public boolean goalTest(SearchTreeNode currentNodeInput) {
		StateEndgame currentState = (StateEndgame) currentNodeInput.getState();
		boolean[] warriorsAround = warriorsAround(currentState.getPosition(), warriors);
		boolean[] thanosAround=thanosAround(currentState);
		int[] damage = calculateDamage(currentState, warriorsAround, thanosAround);
		if((currentState.getDamage() + damage[0] + damage[1]) < 100 && currentState.getPosition().equals(thanosPostion)&& 
				currentState.getStonesLeft().isEmpty()) { //&& currentNodeInput.getAction().equals("snap"))  {
			return true;
		}
		else
			return false;
	}


	/*
	 * Transition function takes the as input the stateCost which contains both the cost and the current state inside it and the next action
	 * from that action it applies the needed transformation to generate a new search tree node
	 */
	@Override
	public StateCost transition(StateCost stateCostInput, String action) {

		//first we get the stateEndgame from the stateCostInput to get all the needed information
		StateEndgame state = (StateEndgame) stateCostInput.getState();
		String[] pos= state.getPosition().split(",");
		int postionX= Integer.parseInt(pos[0]);
		int postionY= Integer.parseInt(pos[1]);

		//using the helper methods warriorsAround to check if there is any warrior around
		boolean[] warriorsAround= warriorsAround(state.getPosition(), state.getWarriorsLeft());
		//thanosAround used to check if Thanos is any cell around IronMan or in the same cell with him 
		boolean[] thanosAround= thanosAround(state);

		int damage = state.getDamage();
		//Calculate the total damage from the environment around plus the original damage so far 
		int[] damageAdjacent = calculateDamage(state, warriorsAround, thanosAround);
		int totalDamageAdjacent = damageAdjacent[0] + damageAdjacent[1];

		//Now we check the performed action
		if(action.equals("kill")) {
			
			// we make a copy from the warriors collections to edit them for the next state/node
			//without affecting the original collection so it does not affect another branch
			HashSet<String> warriorsCopy= (HashSet<String>)state.getWarriorsLeft().clone();
			boolean canKill= false;
			int warriorsKillCount =0;

			//looping on the copy of warriors set and checking if there is any warrior to kill from the boolean array warriorsAround
			for (int i = 0; i < warriorsAround.length; i++) {
				if(warriorsAround[i]) {
					
					// increment the count of warriors that IronMan can kill
					warriorsKillCount++;
					canKill= true;
					
					//Remove the killed warrior from the copy set according to his position
					if(i==0)
						warriorsCopy.remove((postionX-1)+","+(postionY));
					if(i==1)
						warriorsCopy.remove((postionX+1)+","+(postionY));
					if(i==2)
						warriorsCopy.remove((postionX)+","+(postionY+1));
					if(i==3)
						warriorsCopy.remove((postionX)+","+(postionY-1));
				}

			}
			//check if there is any warriors to kill
			if(canKill)
			{ 
				// calculate the total damage resulted from killing all warriors around
				int totalDamage = damage + (warriorsKillCount * 2) + damageAdjacent[0];
				
				//if the damage is greater than 99 then this branch does not lead to a goal test so it does not have any children 
				if(totalDamage > 99) {
					return null;
				}
				
				// The damage is less than 99 so we create a new child which consists of
				// the same stones set as the parent state (since the action is not collect)
				//and the updated copy of warriors and the total damage 
				//total damage calculated from the last damage of the parent, the damage of killing any warrior and the damage from the environment
				StateEndgame newChild = new StateEndgame(state.getPosition(),
						state.getStonesLeft(),warriorsCopy,totalDamage);

				return new StateCost(newChild, totalDamage);
			}
			// if there are no warriors to kill so this action is not valid so we return null (no child)
			else {
				return null;
			}


		}
		else if(action.equals("collect")){  
			
			// make a copy from the stones collections to edit them for the next state/node
			//without affecting the original collection so it does not affect another branch
			HashSet<String> stonesCopy= (HashSet<String>)state.getStonesLeft().clone();
			
			// checking if there is a stone in the same cell as IronMan to collect 
			if(stonesCopy.contains((postionX)+","+(postionY)))
			{	
				//remove that stone from the copy stones set
				stonesCopy.remove((postionX)+","+(postionY));
				
				//update the total damage after collecting the stone
				int totalDamage = damage + totalDamageAdjacent + 3;

				//if the damage is greater than 99 then this branch does not lead to a goal test so it does not have any children 
				if(totalDamage > 99)
					return null;

				// The damage is less than 99 so we create a new child which consists of
				// the same warriors set as the parent state (since the action is not kill)
				//and the updated copy of stones and the total damage 
				//total damage calculated from the last damage of the parent, the damage of collecting a stone and the damage from the environment
				StateEndgame newChild = new StateEndgame(state.getPosition(),
						stonesCopy,state.getWarriorsLeft(), totalDamage);//, state.getStonesLeftCount() - 1, state.getWarriorsLeftCount());

				return new StateCost(newChild, totalDamage);
			}
			//if there is no stone in the same position as IronMan then the action collect is not valid so return null
			else
				return null;
		}
		
		else if(action.contentEquals("up")) {
			//using the warriorsAround to check if there is a warrior in the cell above IronMan (can not move to a cell containing a warrior)
			//using the thanosAround to check if Thanos is in the cell above IronMan (can not move to Thanos's cell unless all the stones are collected)
			//so if either are true or IronMan is at the top of the grid then this is an invalid action 
			if(warriorsAround[0] || (thanosAround[0] && state.getStonesLeft().size() != 0 && state.getDamage() < 95) || postionX==0)
				return null;
			else {
				//calculating the total damage from the environment 
				int totalDamage = damage + totalDamageAdjacent;

				//if the damage is greater than 99 then this branch does not lead to a goal test so it does not have any children 
				if(totalDamage > 99)
					return null;

				// The damage is less than 99 so we create a new child which consists of
				// the same warriors and stones sets as the parent state (since the action is not kill or collect)
				//and the updated copy of stones and the total damage from the environment
				StateEndgame newChild = new StateEndgame(postionX-1+","+(postionY),
						state.getStonesLeft(),state.getWarriorsLeft(),totalDamage);
				return new StateCost(newChild, totalDamage);
			}

		}
		else if(action.equals("down")) {
			//using the warriorsAround to check if there is a warrior in the cell below IronMan (can not move to a cell containing a warrior)
			//using the thanosAround to check if Thanos is in the cell below IronMan (can not move to Thanos's cell unless all the stones are collected)
			//so if either are true or IronMan is at the bottom of the grid then this is an invalid action
			if(warriorsAround[1] || (thanosAround[1] && state.getStonesLeft().size() != 0 && state.getDamage() < 95) || postionX==height-1)
				return null;
			else {

				//calculating the total damage from the environment 
				int totalDamage = damage + totalDamageAdjacent;
				
				//if the damage is greater than 99 then this branch does not lead to a goal test so it does not have any children 
				if(totalDamage > 99)
					return null;


				// The damage is less than 99 so we create a new child which consists of
				// the same warriors and stones sets as the parent state (since the action is not kill or collect)
				//and the updated copy of stones and the total damage from the environment
				StateEndgame newChild = new StateEndgame(postionX+1+","+((Integer)postionY),
						state.getStonesLeft(),state.getWarriorsLeft(),totalDamage);//, state.getStonesLeftCount(), state.getWarriorsLeftCount());
				return new StateCost(newChild, totalDamage);
			}

		}
		else if(action.equals("right")) {
			//using the warriorsAround to check if there is a warrior in the cell on the right of IronMan (can not move to a cell containing a warrior)
			//using the thanosAround to check if Thanos is in the cell on the right of IronMan (can not move to Thanos's cell unless all the stones are collected)
			//so if either are true or IronMan is at the end of the grid from the right then this is an invalid action
			if(warriorsAround[2] || (thanosAround[2] && state.getStonesLeft().size() != 0 && state.getDamage() < 95) || postionY==width-1)
				return null;
			else {

				//calculating the total damage from the environment 
				int totalDamage = damage + totalDamageAdjacent;
				
				//if the damage is greater than 99 then this branch does not lead to a goal test so it does not have any children 
				if(totalDamage > 99)
					return null;
				// The damage is less than 99 so we create a new child which consists of
				// the same warriors and stones sets as the parent state (since the action is not kill or collect)
				//and the updated copy of stones and the total damage from the environment
				StateEndgame newChild = new StateEndgame((postionX)+","+(Integer)(postionY+1),
						state.getStonesLeft(),state.getWarriorsLeft(),totalDamage);//, state.getStonesLeftCount(), state.getWarriorsLeftCount());
				return new StateCost(newChild, totalDamage);

			}


		}
		else if(action.equals("left")) {

			//calculating the total damage from the environment 
			int totalDamage = damage + totalDamageAdjacent;

			//if the damage is greater than 99 then this branch does not lead to a goal test so it does not have any children 
			if(totalDamage > 99)
				return null;

			//using the warriorsAround to check if there is a warrior in the cell on the left of IronMan (can not move to a cell containing a warrior)
			//using the thanosAround to check if Thanos is in the cell on the left of IronMan (can not move to Thanos's cell unless all the stones are collected)
			//so if either are true or IronMan is at the end of the grid from the left then this is an invalid action
			if(warriorsAround[3] || (thanosAround[3] && state.getStonesLeft().size() != 0 && state.getDamage() < 95) || postionY==0)
				return null;
			else {
				
				// The damage is less than 99 so we create a new child which consists of
				// the same warriors and stones sets as the parent state (since the action is not kill or collect)
				//and the updated copy of stones and the total damage from the environment
				StateEndgame newChild = new StateEndgame((postionX)+","+(Integer)(postionY-1),
						state.getStonesLeft(),state.getWarriorsLeft(), totalDamage);//, state.getStonesLeftCount(), state.getWarriorsLeftCount());
				return new StateCost(newChild, totalDamage);
			}

		}
		// The damage is less than 99 so we create a new child which consists of
		// the same warriors and stones sets as the parent state (since the action is not kill or collect)
		//and the updated copy of stones and the total damage from the environment
		return null;
	}


	
	//prints the Grid 
	public void printGrid(String[][] grid) {
		for(int i = 0; i < height; i++) {
			for(int j = 0; j < width; j++) {
				if(grid[i][j] == null || grid[i][j].equals(""))
					System.out.print(".");
				else
					System.out.print(grid[i][j]);
			}
			System.out.println();
		}
	}


	/*
	 * takes as input a searchTreeNode and returns the path from the root till that node
	 * GenericSearch#generateSolution(SearchTreeNode)
	 */
	@Override
	public String generateSolution(SearchTreeNode node) {
		String path = node.getAction();
		while(node.getParent().getAction() != null) {
			//			System.out.println(node.action);
			path = node.getParent().getAction() + "," +path;
			node = node.getParent();
		}
		path += ",snap";
		return path;

	}

	/*
	 * Prints the Grid each time after preforming each action and following the path from the initial state till a goal node 
	 * according to the input solution
	 * GenericSearch#visualizeGrid(java.lang.String, java.lang.String)
	 */
	@Override
	public void visualizeGrid(String inputGrid, String solution) {
		//first we prepare the Grid from the initial state: IronMan position, stones' positions and warriors' positions
		String[][] grid = new String[height][width];	
		for(int i = 0; i < grid.length; i++) {
			for(int j = 0; j < grid[0].length; j++)
				grid[i][j] = "";
		}
		String[] splitSolution = solution.split(",");
		splitSolution[splitSolution.length-1] = splitSolution[splitSolution.length-1].split(";")[0];
		grid[Integer.parseInt(thanosPostion.split(",")[0])][Integer.parseInt(thanosPostion.split(",")[1])] = "T";
		int ironManPositionX = Integer.parseInt(ironManPosition.split(",")[0]);
		int ironManPositionY = Integer.parseInt(ironManPosition.split(",")[1]);
		grid[ironManPositionX][ironManPositionY] = "I";

		HashSet<String> warriorsCopy= new HashSet<>(warriors);

		for (Iterator<String> iterator = stones.iterator(); iterator.hasNext();) {
			String postionString = (String) iterator.next();
			int posX=Integer.parseInt(postionString.split(",")[0]);
			int posY=Integer.parseInt(postionString.split(",")[1]);
			grid[posX][posY]="S";
		}
		for (Iterator<String> iterator = warriors.iterator(); iterator.hasNext();) {
			String postionString = (String) iterator.next();
			int posX=Integer.parseInt(postionString.split(",")[0]);
			int posY=Integer.parseInt(postionString.split(",")[1]);
			grid[posX][posY]="W";
		}
		System.out.println("Initial Grid");
		printGrid(grid);
		// Loop on the solution which contains the path from the initial state till the goal state
		for(int i = 0; i < splitSolution.length; i++) {
			System.out.println("///////////////////////////");
			System.out.println("Action:" + splitSolution[i]);
			//check which action was preformed in each step 
			switch(splitSolution[i]) {
			case "up":
				grid[ironManPositionX][ironManPositionY] = grid[ironManPositionX][ironManPositionY].replace("I", "");
				ironManPositionX -= 1;
				grid[ironManPositionX][ironManPositionY] = "I" + grid[ironManPositionX][ironManPositionY];
				break;
			case "down":
				grid[ironManPositionX][ironManPositionY] = grid[ironManPositionX][ironManPositionY].replace("I", "");
				ironManPositionX += 1;
				grid[ironManPositionX][ironManPositionY] = "I" + grid[ironManPositionX][ironManPositionY];
				break;
			case "right":
				grid[ironManPositionX][ironManPositionY] = grid[ironManPositionX][ironManPositionY].replace("I", "");
				ironManPositionY += 1;
				grid[ironManPositionX][ironManPositionY] = "I" + grid[ironManPositionX][ironManPositionY];
				break;
			case "left":
				grid[ironManPositionX][ironManPositionY] = grid[ironManPositionX][ironManPositionY].replace("I", "");
				ironManPositionY -= 1;
				grid[ironManPositionX][ironManPositionY] = "I" + grid[ironManPositionX][ironManPositionY];
				break;
			case "collect":
				grid[ironManPositionX][ironManPositionY] = "I";
				break;
			case "kill":
				boolean[] warriorsAround = warriorsAround(ironManPositionX +"," + ironManPositionY, warriorsCopy);
				for(int j = 0; i < warriorsAround.length; j++) {
					if(warriorsAround[0] == true)
						grid[ironManPositionX-1][ironManPositionY] = "";
					warriorsCopy.remove(ironManPositionX-1+","+(ironManPositionY));

					if(warriorsAround[1] == true)
						grid[ironManPositionX+1][ironManPositionY] = "";
					warriorsCopy.remove((ironManPositionX+1)+","+(ironManPositionY));

					if(warriorsAround[2] == true)
						grid[ironManPositionX][ironManPositionY+1] = "";
					warriorsCopy.remove(ironManPositionX+","+(ironManPositionY+1));

					if(warriorsAround[3] == true)
						grid[ironManPositionX][ironManPositionY-1] = "";
					warriorsCopy.remove(ironManPositionX+","+(ironManPositionY-1));
				}
				break;
			case "snap":
				grid[ironManPositionX][ironManPositionY] = "I";
				break;

			}
			printGrid(grid);
		}



	}

}
