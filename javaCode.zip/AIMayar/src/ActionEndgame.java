
public class ActionEndgame extends Action{

	//private String[] actions;
	
	public ActionEndgame(String[] actions) {
		super(actions);

	}

	
}
