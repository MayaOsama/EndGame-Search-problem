import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.PriorityQueue;


/*
 * NodeCompartor is a subclass that is used to compare two searchTreeNodes using their cost from root
 */
class NodeCompartor implements Comparator<SearchTreeNode>{ 

	@Override
	public int compare(SearchTreeNode n1, SearchTreeNode n2) {
		return n1.getCostFromRoot() - n2.getCostFromRoot();
	}
}
/*
 * NodeCompartor is a subclass that is used to compare two searchTreeNodes using their greedy cost
 */
class GreedyNodes implements Comparator<SearchTreeNode>{ 

	@Override
	public int compare(SearchTreeNode n1, SearchTreeNode n2) {
		return n1.getGreedyCost() - n2.getGreedyCost();
	}
}

/*
 * NodeCompartor is a subclass that is used to compare two searchTreeNodes using their Astar cost( the cost from root plus its greedy cost)
 */
class AstarNodes implements Comparator<SearchTreeNode>{ 

	@Override
	public int compare(SearchTreeNode n1, SearchTreeNode n2) {
		return n1.get_AstartCost() - n2.get_AstartCost();
	}
}

/*
 * KeyState class used for the repeated states
 * we check if a state is a repeated state using IronMan's position, stones left set and warriors left set
 */
class KeyState {
	private String position;
	private HashSet<String> stonesLeft;
	private HashSet<String> warriorsLeft;
	public KeyState(State state) {
		this.setPosition(((StateEndgame)state).getPosition());
		this.setStonesLeft(((StateEndgame)state).getStonesLeft());
		this.setWarriorsLeft(((StateEndgame)state).getWarriorsLeft());


	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}

	public HashSet<String> getStonesLeft() {
		return stonesLeft;
	}
	public void setStonesLeft(HashSet<String> stonesLeft) {
		this.stonesLeft = stonesLeft;
	}
	public HashSet<String> getWarriorsLeft() {
		return warriorsLeft;
	}
	public void setWarriorsLeft(HashSet<String> warriorsLeft) {
		this.warriorsLeft = warriorsLeft;
	}
	
	/*
	 * compares the positions and the stones left sets 
	 */
	
	@Override
	public boolean equals(Object state) {
		if(this == state) {
			return true;
		}
		
		return this.position.equals( ((KeyState)state).position) 
				&& this.stonesLeft.equals(((KeyState)state).getStonesLeft()); 
	}
	
	/*
	 * editing the hashCode of the class to contain the position
	 * and each stone and warrior's positions 
	 * 
	 */
    @Override
    public int hashCode() {
    	final int prime = 31;
//    	int resultFinal = 1;
    	int resultFinal = ((int)position.charAt(0) - ((int)position.charAt(2))); //+ stonesLeft.size() + warriorsLeft.size());
    	
    	int result = 1;
    	for( String s : stonesLeft)
    	{
    	    result = prime + ((int)s.charAt(0) - ((int)s.charAt(2)));
    	}
    	for( String s : warriorsLeft)
    	{
    	    result = prime + ((int)s.charAt(0) - ((int)s.charAt(2)));
    	}
    	return result + resultFinal;
//        return resultFinal;
        		
      }

}


/*
 * GenericSearch class is an abstract class that can work on any search problem
 * (except for the Greedy and A_star search strategies)
 */
public abstract class GenericSearch {
	State initialState;
	Action actions;
	int limit;
	HashSet<KeyState> repeatedSet;
	public GenericSearch(State initialState, Action actions) {
		this.initialState = initialState;
		this.actions = actions;
		repeatedSet= new HashSet<>();
		repeatedSet.add(new KeyState(initialState));
	}

	/*
	 *	 
	 */
	public ArrayList<String> generalSearch(String grid, String strategy, boolean visualize, int limitIDS) {
		ArrayList<String> output= new ArrayList<>();
		repeatedSet= new HashSet<>();
		repeatedSet.add(new KeyState(initialState));
		limit = limitIDS;
		ArrayList<SearchTreeNode> queue = new ArrayList<SearchTreeNode>();
		//add the initial state to be the root of the searchTree
		queue.add(new SearchTreeNode(this.getInitialState(), null, null, 0, 0));
		String solution = "There is no solution.";
		int nodesExpanded = 0;
		
		//keep looping until there are no more nodes in the queue to expand
		while(!queue.isEmpty()) {
			
			//get the first node in the queue
			SearchTreeNode node = queue.remove(0);
			
			//increment the count of expanded nodes
			nodesExpanded++;

			//check if the current node is a goal node using the goalTest method
			boolean isGoal = goalTest(node);

			if(isGoal) {
				
				//update the solution after generating the path from root to goal node 
				// and add to it the total cost and the number of expanded nodes during the search
				
				solution = this.generateSolution(node) + ";" + node.getCostFromRoot() ;
//						+";" + nodesExpanded;
				if(visualize) {
					visualizeGrid(grid, solution);
				}
				output.add(solution);
				output.add(nodesExpanded+"");
				return output;
			} 
			else{

				//the current node is not a goal node so generate its children by looping on the given actions
				ArrayList<SearchTreeNode> children = new ArrayList<SearchTreeNode>();
				for(String action : actions.getActions()) {
					// call the transition method to check if there exits a child from this action
					StateCost childStateCost = transition(new StateCost(node.getState(), node.getCostFromRoot()), action);
					if(childStateCost!=null) {
						
						SearchTreeNode newNode= new SearchTreeNode(childStateCost.getState(), node, action, childStateCost.getCost(), node.getDepth()+1);							
						boolean repeatedState= repeatedSet.contains(new KeyState(newNode.getState()));
						//check if the resulted node from the transition method is a repeated state to avoid infinite loops
						if(!repeatedState)
						{

							// not a repeated state then add it to the repeated states set
							repeatedSet.add(new KeyState(newNode.getState()));
							//add it to the children array
							children.add(newNode);
						}

					}
				}
				//check which strategy to apply 
				switch(strategy) {
				case "BF":
					breadthFirstSearch(queue,children);
					break;
				case "DF":
					depthFirstSearch(queue,children);
					break;
				case "ID":
					iterativeDeepeningSearch(queue, children,grid,visualize);
					break;
				case "UC":
					queue = uniformCostSearch(queue, children);
					break;
				case "GR1":
					queue = greedy1(queue, children);
					break;
				case "GR2":
					queue = greedy2(queue, children);
					break;
				case "AS1":
					queue =_Astar1(queue, children);
					break;
				case "AS2":
					queue = _Astar2(queue, children);
					break;
				}
			}
		}
		output.add(solution);
		output.add(nodesExpanded+"");
		return output;
	}

	public State getInitialState() {
		return this.initialState;
	}

	public abstract boolean goalTest(SearchTreeNode currentNodeInput);

	public abstract StateCost transition(StateCost state, String action);

	/*
	 * uniformCostSearch rearranges the queue according to their cost from root
	 */
	public ArrayList<SearchTreeNode> uniformCostSearch(ArrayList<SearchTreeNode> nodes, ArrayList<SearchTreeNode> children) {
		PriorityQueue<SearchTreeNode> nodesSorted = new PriorityQueue<>(new NodeCompartor());
		nodesSorted.addAll(nodes);

		for(int i = 0; i < children.size(); i++) {
			
			nodesSorted.add(children.get(i));
		}

		return new ArrayList<>(nodesSorted);

	}

	/*
	 * breadthFirstSearch adds the children to the end of the queue
	 */
	public void breadthFirstSearch(ArrayList<SearchTreeNode> queue,ArrayList<SearchTreeNode> children) {
		for (int i = 0; i < children.size(); i++) {
			queue.add(children.get(i));
		}
	}
	

	/*
	 * depthFirstSearch adds the children to the start of the queue
	 */
	public void  depthFirstSearch(ArrayList<SearchTreeNode> queue,ArrayList<SearchTreeNode> children) {
		for(int i =0 ; i< children.size(); i++) {
			queue.add(0,children.get(i));

		}

	}


	/*
	 * depthLimitedSearch helper method for iterativeDeepeningSearch the  adds the children to the start of the queue after checking its depth 
	 */	
	public void depthLimitedSearch(ArrayList<SearchTreeNode> queue,ArrayList<SearchTreeNode> children,String grid,  boolean visualize) {
		//		ArrayList<SearchTreeNode> expanded= new ArrayList<>();
		for (int i = 0; i < children.size(); i++) {
			if(children.get(i).getDepth() <= limit) {
				queue.add(0,children.get(i));
			}

		}




	}
	public void iterativeDeepeningSearch(ArrayList<SearchTreeNode> queue ,ArrayList<SearchTreeNode> children ,String grid, boolean visualize) {
		depthLimitedSearch(queue,children,grid,visualize);
			
	}


	public abstract void visualizeGrid(String inputGrid, String solution);
	public abstract String generateSolution(SearchTreeNode node);

	
	/*
	 * calculates and sets the greedy cost of a node according to the first heuristic function
	 * which is the number of stones left multiplied by their damage 
	 */
	public void calculateGreedy1(SearchTreeNode node) {
		//Damage of stones left
		node.setGreedyCost( ( (StateEndgame)node.getState()).getStonesLeft().size()*3);
	}

	/*
	 * calculates and sets the greedy cost of a node according to the second heuristic function
	 * which is the number of stones left multiplied by their damage plus the number of warriors around the remaining stones
	 */
	public void calculateGreedy2(SearchTreeNode node) {
		//Damage of stones left + damage of warriors adjacent to stones and Thanos 
		int count =((StateEndgame)node.getState()).warriorsAroundStones();
		node.setGreedyCost( ((StateEndgame)node.getState()).getStonesLeft().size()*3+count);
	}

	/*
	 * calculates and sets the greedy cost of a node according to the first heuristic function and the cost from root to that node
	 * which is the number of stones left multiplied by their damage 
	 */
	public void calculateAstar_1(SearchTreeNode node) {
		calculateGreedy1(node);
		node.set_AstartCost( node.getGreedyCost()+ node.getCostFromRoot());
	}

	/*
	 * calculates and sets the A_star cost of a node according to the second heuristic function and the cost from root to that node
	 * which is the number of stones left multiplied by their damage plus the number of warriors around the remaining stones
	 */
	public void calculateAstar_2(SearchTreeNode node) {
		calculateGreedy2(node);
		node.set_AstartCost( node.getGreedyCost()+node.getCostFromRoot());
	}



	/*
	 * greedy1 rearranges the queue according to their greedy cost
	 * after calculating the cost by the first heuristic function using calculateGreedy1
	 */	
	public  ArrayList<SearchTreeNode> greedy1(ArrayList<SearchTreeNode> queue ,ArrayList<SearchTreeNode> children){
		PriorityQueue<SearchTreeNode> GreedyQueue= new PriorityQueue<>(new GreedyNodes());
		//sort queue according to the first heuristic function
		GreedyQueue.addAll(queue);
		for (int i = 0; i < children.size(); i++) {
			calculateGreedy1(children.get(i));
			GreedyQueue.add(children.get(i));	


		}

		return new ArrayList<>(GreedyQueue);
	}

	/*
	 * greedy2 rearranges the queue according to their greedy cost
	 * after calculating the cost by the second heuristic function using calculateGreedy2
	 */	
	public  ArrayList<SearchTreeNode> greedy2(ArrayList<SearchTreeNode> queue ,ArrayList<SearchTreeNode> children){
		PriorityQueue<SearchTreeNode> GreedyQueue= new PriorityQueue<>(new GreedyNodes());
		//sort queue according to the first heuristic function
		GreedyQueue.addAll(queue);
		for (int i = 0; i < children.size(); i++) {
			calculateGreedy2(children.get(i));
			GreedyQueue.add(children.get(i));	


		}

		return new ArrayList<>(GreedyQueue);
	}


	/*
	 * _Astar1 rearranges the queue according to their greedy cost
	 * after calculating the cost by the first A_star cost calculateAstar_1
	 */	
	public  ArrayList<SearchTreeNode> _Astar1(ArrayList<SearchTreeNode> queue ,ArrayList<SearchTreeNode> children){
		PriorityQueue<SearchTreeNode> AstarQueue= new PriorityQueue<>(new AstarNodes());
		//sort queue according to the first heuristic function
		AstarQueue.addAll(queue);
		for (int i = 0; i < children.size(); i++) {
			calculateAstar_1(children.get(i));
			AstarQueue.add(children.get(i));	
		}

		return new ArrayList<>(AstarQueue);
	}


	/*
	 * _Astar2 rearranges the queue according to their greedy cost
	 * after calculating the cost by the second A_star cost calculateAstar_2
	 */	
	public  ArrayList<SearchTreeNode> _Astar2(ArrayList<SearchTreeNode> queue ,ArrayList<SearchTreeNode> children){
		PriorityQueue<SearchTreeNode> AstarQueue= new PriorityQueue<>(new AstarNodes());
		//sort queue according to the first heuristic function
		AstarQueue.addAll(queue);

		for (int i = 0; i < children.size(); i++) {

			calculateAstar_2(children.get(i));
			AstarQueue.add(children.get(i));	
		}

		return new ArrayList<>(AstarQueue);
	}

}