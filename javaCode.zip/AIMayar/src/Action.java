
public abstract class Action {
	private String[] actions;
	
	public Action(String[] actions) {
		this.actions = actions;
	}
	
	public String[] getActions() {
		return this.actions;
	}
	
}