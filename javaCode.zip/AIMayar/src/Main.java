import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;

public class Main {
	public static String solve(String grid, String strategy, boolean visualize){
		String[] splitArray = grid.split(";");
		String ironManPosition= splitArray[1];

		// set the stones and warriors sets with the input values after splitting 
		HashSet<String> stones = concatenate(new ArrayList<>(Arrays.asList(splitArray[3].split(","))));
		HashSet<String> warriors = concatenate(new ArrayList<>(Arrays.asList(splitArray[4].split(","))));

		// create the initial state by the initial IronMan postion and the initial stones and warriors sets
		State initialState = new StateEndgame(ironManPosition, stones, warriors, 0);//, stones.size(), warriors.size());
		Endgame endgame = new Endgame((StateEndgame)initialState,
				new ActionEndgame(new String[]{"collect", "kill", "up", "down", "right", "left"}),
				splitArray[2],splitArray[0].split(",")[0],splitArray[0].split(",")[1]);
		
		int nodesExpanded=0;
		//calling the general search with the given input and starting the limit of the IDS with 0
		ArrayList<String> solutionArray = endgame.generalSearch(grid, strategy, visualize, 0);
		String solution= solutionArray.get(0);
		nodesExpanded+= Integer.parseInt(solutionArray.get(1));
		//for the IDS we need to increment the limit each time we don't find a solution and recall the generalSearch method 
		if(strategy.equals("ID")) {
			if(solution.equals("There is no solution.")) {
				for(int i = 1; i < 500; i++) {
					solutionArray = endgame.generalSearch(grid, strategy, visualize, i);
					solution= solutionArray.get(0);
					nodesExpanded+= Integer.parseInt(solutionArray.get(1));

					if(!solution.equals("There is no solution.")) {
						break;
					}
				}
			}
		}
		if(!solution.equals("There is no solution.")) 
			solution+=";" + nodesExpanded;
		return solution;

	}
	
	/*
	 * concatenate is a helper method to add the position x and y from a split array into the same cell in the output HashShet 
	 */
	public static HashSet<String> concatenate(ArrayList<String> startArray) {
		HashSet<String> endArray= new HashSet<>();
		for (int i = 0; i < startArray.size()-1; i+=2) {
			endArray.add(startArray.get(i)+","+startArray.get(i+1));
		}
		return endArray;
	}

	public static void main(String[] args) {
		long start = System.currentTimeMillis();
		String solution = solve("6,6;5,3;0,1;4,3,2,1,3,0,1,2,4,5,1,1;1,3,3,3,1,0,1,4,2,2", "AS2", false);
		long end = System.currentTimeMillis();
		System.out.println(solution);
	      //finding the time difference and converting it into seconds
	      float sec = (end - start) ; 
	      System.out.println(sec + " Miliseconds");
	      
		System.out.println("end");

	}

}

