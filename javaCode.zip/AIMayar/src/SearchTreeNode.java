
public class SearchTreeNode {
	private State state;
	private SearchTreeNode parent;
	private String action;
	private int costFromRoot;
	private int depth;
	private int greedyCost;
	private int _AstartCost;


	public SearchTreeNode(State state,	SearchTreeNode parent,	String action,	int costFromRoot,
			int depth) {
		// TODO Auto-generated constructor stub
		this.state=state;
		this.action=action;
		this.costFromRoot=costFromRoot;
		this.parent=parent;
		this.depth=depth;
		this.setGreedyCost(0);
		this.set_AstartCost(0);

	}

	public State getState() {
		return state;
	}

	public void setState(State state) {
		this.state = state;
	}

	public SearchTreeNode getParent() {
		return parent;
	}

	public void setParent(SearchTreeNode parent) {
		this.parent = parent;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public int getCostFromRoot() {
		return costFromRoot;
	}

	public void setCostFromRoot(int costFromRoot) {
		this.costFromRoot = costFromRoot;
	}

	public int getDepth() {
		return depth;
	}

	public void setDepth(int depth) {
		this.depth = depth;
	}

	public int getGreedyCost() {
		return greedyCost;
	}

	public void setGreedyCost(int greedyCost) {
		this.greedyCost = greedyCost;
	}

	public int get_AstartCost() {
		return _AstartCost;
	}

	public void set_AstartCost(int _AstartCost) {
		this._AstartCost = _AstartCost;
	}

}
