import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;

public class StateEndgame extends State {
	private String position;
	private HashSet<String> stonesLeft;
	private HashSet<String> warriorsLeft;
	private int warriorsArroundStones;
	private int damage;

	public StateEndgame(String postion,HashSet<String> stones,HashSet<String> warriors,int damage){
		this.position = postion;
		this.damage = damage;
		stonesLeft=stones;
		warriorsLeft=warriors;
	}

	/*
	 * warriorsAroundStones calculates the number of warriors around each stone
	 * the key is the position of each stone and the value is the count of the warriors around that stone
	 */
	public int warriorsAroundStones() {
		int count=0;
		for (Iterator<String> iterator = stonesLeft.iterator(); iterator.hasNext();) {
			String postion = (String) iterator.next();
			String[] pos = postion.split(",");
			int postionX= Integer.parseInt(pos[0]+"");
			int postionY= Integer.parseInt(pos[1]+"");
			if(warriorsLeft.contains((postionX-1)+","+(postionY)))
				count++;
			if(warriorsLeft.contains((postionX+1)+","+(postionY)))
				count++;
			if(warriorsLeft.contains((postionX)+","+(postionY+1)))
				count++;
			if(warriorsLeft.contains((postionX)+","+(postionY-1)))
				count++;
			

			
		}
		
			
		return count;
		
	}
	
	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public HashSet<String> getStonesLeft() {
		return stonesLeft;
	}

	public void setStonesLeft(HashSet<String> stonesLeft) {
		this.stonesLeft = stonesLeft;
	}

	public HashSet<String> getWarriorsLeft() {
		return warriorsLeft;
	}

	public void setWarriorsLeft(HashSet<String> warriorsLeft) {
		this.warriorsLeft = warriorsLeft;
	}

	public int getDamage() {
		return damage;
	}

	public void setDamage(int damage) {
		this.damage = damage;
	}
	
	public int getWarriorsArroundStones() {
		return warriorsArroundStones;
	}

	public void setWarriorsArroundStones(int warriorsArroundStones) {
		this.warriorsArroundStones = warriorsArroundStones;
	}
}
